plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.celzip.proxxy"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.celzip.proxxy"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "1.0.0"
    }
}
