package com.celzip.proxxy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 14, 24)
    private val cyan = Color.rgb(0, 229, 255)
    private val prefs by lazy { getSharedPreferences("celzip_config", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        render()
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(layout)
        setContentView(scroll)
        layout.addView(TextView(this).apply {
            text = "CELZIP PROXY"; textSize = 26f; setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        layout.addView(label("NATIVE ANDROID • NO ROOT • NO VIRTUAL SPACE"))
        layout.addView(label("DEVICE INFO\\nManufacturer: ${Build.MANUFACTURER}\\nModel: ${Build.MODEL}\\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\\nApp version: ${packageManager.getPackageInfo(packageName, 0).versionName}"))
        val allowed = Settings.canDrawOverlays(this)
        layout.addView(label("OVERLAY PERMISSION: ${if (allowed) "GRANTED" else "NOT GRANTED"}").apply { setTextColor(cyan) })
        layout.addView(action("GRANT OVERLAY PERMISSION") {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show()
        })
        layout.addView(action("START FLOATING PANEL") {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        layout.addView(action("STOP FLOATING PANEL") { stopService(Intent(this, OverlayService::class.java)) })
        layout.addView(action("LOAD LAST PRESET") {
            val snapshot = prefs.getString("preset_last", null)
            if (snapshot.isNullOrBlank()) Toast.makeText(this, "Belum ada preset tersimpan", Toast.LENGTH_SHORT).show()
            else {
                snapshot.split(";").forEach { item ->
                    val pair = item.split("=", limit = 2)
                    if (pair.size == 2) {
                        when (pair[1]) {
                            "true", "false" -> prefs.edit().putBoolean(pair[0], pair[1].toBoolean()).apply()
                            else -> pair[1].toIntOrNull()?.let { prefs.edit().putInt(pair[0], it).apply() }
                        }
                    }
                }
                Toast.makeText(this, "Preset terakhir dimuat. Buka ulang panel untuk menerapkan semua pengaturan.", Toast.LENGTH_LONG).show()
            }
        })
        layout.addView(action("AIM TRAINING • HEADSHOT PRACTICE") { startActivity(Intent(this, AimTrainingActivity::class.java)) })
        layout.addView(action("OPEN FREE FIRE") { launchGame() })
        layout.addView(label("Catatan: crosshair adalah overlay visual. Aim Training adalah latihan lokal dengan target simulasi; tidak mengendalikan bidikan Free Fire. ESP/radar tidak mendeteksi musuh dalam game; AIMLOCK dan bypass anti-cheat tidak disertakan."))
    }

    private fun launchGame() {
        for (pkg in listOf("com.dts.freefireth", "com.dts.freefiremax")) {
            packageManager.getLaunchIntentForPackage(pkg)?.let {
                startActivity(it); return
            }
        }
        Toast.makeText(this, "Free Fire / Free Fire MAX tidak ditemukan.", Toast.LENGTH_LONG).show()
    }
    private fun label(s: String) = TextView(this).apply { text=s; textSize=13f; setTextColor(Color.LTGRAY); setPadding(0,8,0,8) }
    private fun action(s: String, f: () -> Unit) = Button(this).apply {
        text=s; isAllCaps=false; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(30,42,60))
        setOnClickListener { f() }
        layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin=6; bottomMargin=6 }
    }
}
