package com.celzip.proxxy

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object { const val ACTION_SHOW = "com.celzip.proxxy.SHOW" }
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var crosshair: View? = null
    private var minimized = false
    private val prefs by lazy { getSharedPreferences("celzip_config", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onDestroy() {
        panel?.let { runCatching { wm.removeView(it) } }; panel = null
        crosshair?.let { runCatching { wm.removeView(it) } }; crosshair = null
        super.onDestroy()
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun showPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(12, 17, 29), 22, Color.rgb(0, 229, 255))
            setPadding(14, 12, 14, 12)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "CELZIP PROXY"; textSize = 15f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(smallButton("—") { toggleMinimize(outer) })
        header.addView(smallButton("×") { stopSelf() })
        outer.addView(header)

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outer.addView(body)
        val names = listOf("SHOW GHOST", "SHOW FREEZE", "SHOW TUNEL", "ESP LINE", "ESP BOX", "ESP SKELETON", "ESP ENEMY", "RADAR", "CROSSHAIR")
        names.forEach { name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val t = TextView(this).apply { text = name; textSize = 12f; setTextColor(Color.LTGRAY) }
            row.addView(t, LinearLayout.LayoutParams(0, 38, 1f))
            val key = name.lowercase().replace(" ", "_")
            val initial = prefs.getBoolean(key, name == "CROSSHAIR")
            val b = smallButton(if (initial) "ON" else "OFF") { }
            b.setOnClickListener {
                val now = !prefs.getBoolean(key, name == "CROSSHAIR")
                prefs.edit().putBoolean(key, now).apply()
                b.text = if (now) "ON" else "OFF"
                if (name == "CROSSHAIR") setCrosshair(now)
            }
            row.addView(b)
            body.addView(row)
        }
        val colorButton = smallButton("ESP COLOR") {
            val next = if (prefs.getInt("visual_color", Color.CYAN) == Color.CYAN) Color.MAGENTA else Color.CYAN
            prefs.edit().putInt("visual_color", next).apply()
            (itView(crosshair) as? CrosshairView)?.setColor(next)
        }
        body.addView(colorButton)
        body.addView(smallButton("SAVE PRESET") {
            val snapshot = prefs.all.filterValues { it is Boolean || it is Int }
            prefs.edit().putString("preset_last", snapshot.entries.joinToString(";") { "${it.key}=${it.value}" }).apply()
        })
        body.addView(smallButton("OPEN APP SETTINGS") {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        // Allow dragging from header.
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var x0 = 0; var y0 = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = panel?.layoutParams as? WindowManager.LayoutParams ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; x0 = lp.x; y0 = lp.y; return true }
                    MotionEvent.ACTION_MOVE -> { lp.x = x0 + (e.rawX - sx).toInt(); lp.y = y0 + (e.rawY - sy).toInt(); wm.updateViewLayout(outer, lp); return true }
                }
                return false
            }
        })
        panel = outer
        val lp = params(dp(260), -2).apply { gravity = Gravity.TOP or Gravity.START; x = dp(18); y = dp(100) }
        wm.addView(outer, lp)
        if (prefs.getBoolean("crosshair", true)) setCrosshair(true)
    }

    private fun toggleMinimize(outer: LinearLayout) {
        minimized = !minimized
        if (outer.childCount > 1) outer.getChildAt(1).visibility = if (minimized) View.GONE else View.VISIBLE
        outer.requestLayout()
    }

    private fun setCrosshair(show: Boolean) {
        if (show && crosshair == null) {
            val v = CrosshairView(this)
            crosshair = v
            val lp = params(-1, -1).apply {
                gravity = Gravity.TOP or Gravity.START
                flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            runCatching { wm.addView(v, lp) }.onFailure { crosshair = null }
        } else if (!show && crosshair != null) {
            runCatching { wm.removeView(crosshair) }; crosshair = null
        }
    }

    private fun smallButton(text: String, action: (View) -> Unit) = Button(this).apply {
        this.text = text; textSize = 10f; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(Color.rgb(27, 39, 57), 12, Color.rgb(0, 180, 210))
        setPadding(dp(7), 0, dp(7), 0)
        layoutParams = LinearLayout.LayoutParams(-2, dp(34)).apply { leftMargin = dp(4); topMargin = dp(2); bottomMargin = dp(2) }
        setOnClickListener { action(this) }
    }
    private fun rounded(fill: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun itView(v: View?) = v

    private class CrosshairView(ctx: android.content.Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 3f; style = Paint.Style.STROKE }
        private var color = Color.CYAN
        fun setColor(c: Int) { color = c; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            paint.color = color
            val cx = width / 2f; val cy = height / 2f
            canvas.drawLine(cx - 12, cy, cx - 4, cy, paint)
            canvas.drawLine(cx + 4, cy, cx + 12, cy, paint)
            canvas.drawLine(cx, cy - 12, cx, cy - 4, paint)
            canvas.drawLine(cx, cy + 4, cx, cy + 12, paint)
            canvas.drawCircle(cx, cy, 1.8f, paint)
        }
    }
}
