package com.celzip.proxxy

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.view.ViewGroup
import kotlin.math.hypot
import kotlin.random.Random

/** Standalone local aim-training minigame. It does not inspect or control other apps. */
class AimTrainingActivity : Activity() {
    private lateinit var arena: TrainingArena
    private lateinit var stats: TextView
    private var hits = 0
    private var shots = 0
    private var streak = 0
    private var best = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(9, 13, 24)); setPadding(12, 12, 12, 12) }
        stats = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; text = "HEADSHOT TRAINING • Tap target center"; setPadding(8, 8, 8, 12) }
        arena = TrainingArena()
        root.addView(stats, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(arena, LinearLayout.LayoutParams(-1, 0, 1f))
        val reset = Button(this).apply { text = "RESET SESSION"; setOnClickListener { hits=0; shots=0; streak=0; best=0; arena.newTarget(); updateStats() } }
        root.addView(reset, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        updateStats()
    }

    private fun updateStats() {
        val accuracy = if (shots == 0) 0 else hits * 100 / shots
        stats.text = "HEADSHOT TRAINING  •  Hits $hits  •  Shots $shots  •  Accuracy $accuracy%  •  Streak $streak  •  Best $best\nTap the center ring of the moving target. Local practice only."
    }

    private inner class TrainingArena : View(this@AimTrainingActivity) {
        private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.CYAN; textSize = 32f }
        private var tx = 200f; private var ty = 300f; private var radius = 54f
        private var vx = 5.2f; private var vy = 3.7f
        private var last = System.nanoTime()
        init { setBackgroundColor(Color.rgb(15, 23, 42)); isClickable = true }
        fun newTarget() {
            val w = width.coerceAtLeast(1); val h = height.coerceAtLeast(1)
            tx = Random.nextFloat() * (w - 2 * radius).coerceAtLeast(1f) + radius
            ty = Random.nextFloat() * (h - 2 * radius).coerceAtLeast(1f) + radius
            vx = (Random.nextFloat() * 5f + 2.5f) * if (Random.nextBoolean()) 1 else -1
            vy = (Random.nextFloat() * 4f + 2f) * if (Random.nextBoolean()) 1 else -1
            invalidate()
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val now = System.nanoTime(); val dt = ((now-last)/16_000_000.0).toFloat().coerceIn(0f, 2f); last=now
            if (width > 0 && height > 0) {
                tx += vx*dt; ty += vy*dt
                if (tx < radius || tx > width-radius) vx = -vx
                if (ty < radius || ty > height-radius) vy = -vy
                tx = tx.coerceIn(radius, (width-radius).coerceAtLeast(radius))
                ty = ty.coerceIn(radius, (height-radius).coerceAtLeast(radius))
            }
            targetPaint.color = Color.rgb(139, 92, 246); canvas.drawCircle(tx, ty, radius, targetPaint)
            ringPaint.color = Color.WHITE; canvas.drawCircle(tx, ty, radius*0.66f, ringPaint)
            ringPaint.color = Color.rgb(0, 229, 255); canvas.drawCircle(tx, ty, radius*0.28f, ringPaint)
            canvas.drawLine(tx-16, ty, tx+16, ty, ringPaint); canvas.drawLine(tx, ty-16, tx, ty+16, ringPaint)
            postInvalidateDelayed(16)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN) {
                shots++
                val d = hypot(event.x-tx, event.y-ty)
                if (d <= radius*0.28f) { hits++; streak++; best = maxOf(best, streak); newTarget() }
                else streak = 0
                updateStats(); performClick(); return true
            }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }
}
