# CELZIP PROXY

Native Android overlay starter project (Kotlin, min SDK 26). Includes a compact floating panel, draggable header, minimize/close, real crosshair overlay, local SharedPreferences toggles, simple preset snapshot, launch intent for Free Fire packages, JSON configuration assets, and GitHub Actions build workflow.

## Build
Open this folder in Android Studio with JDK 17, or run `gradle assembleDebug` with Android SDK installed. GitHub Actions workflow is at `.github/workflows/android.yml`.

## Limitations
ESP BOX/LINE/SKELETON/RADAR controls are saved configuration flags only. This app does not read Free Fire process memory, detect real enemies, inject code, or bypass anti-cheat. Crosshair and panel are actual Android overlays and require the user to grant "Display over other apps". The APK has not been compiled in this environment; use CI to validate the build.

## Aim Training

The app includes a standalone local target-training screen. Tap the center ring of the moving target to score a hit. It measures hits, shots, accuracy, current streak, and best streak. This is an isolated training minigame; it does not read Free Fire memory, detect players in Free Fire, or control the game's aim.

## Build

Open this folder in Android Studio, allow Gradle sync, then select **Build > Build APK(s)**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`. This source package has not been compiled or device-tested in this environment.
